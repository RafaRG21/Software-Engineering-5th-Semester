/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servidor;

import Interfaces.chatCliente;
import Interfaces.chatServidor;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Rafael Ruiz
 */
public class implementacionChat extends UnicastRemoteObject implements chatServidor {
    public ArrayList<chatCliente> clientes;
    public String numero = "";
    public int cont = 0, num1 = 0, num2 = 0;

    implementacionChat() throws RemoteException {
        clientes =  new ArrayList<chatCliente>();
    }//Constructor
    public void mensaje(String mensaje, String nombre, String operacion) throws RemoteException{
        int clientNum  = 0;
        Scanner scan = new Scanner(System.in);
        cont++;
        System.out.println(nombre + ": "+mensaje);
        if(cont == 1){
            num1 = Integer.parseInt(mensaje);
        } else if(cont == 2){
            num2 = Integer.parseInt(mensaje);

            switch (operacion){
                case "1":
                    clientNum = 0;
                    while (clientNum<clientes.size()){
                        clientes.get(clientNum).mensajeCliente(String.valueOf("La suma de " + num1 + " y " + num2 + " = " + (num1 + num2)));
                        clientNum++;
                    }
                     System.out.println(String.valueOf(num1 + " + " + num2 + " = " + (num1 + num2)));
                    
                    break;
                case "2":
                    clientNum = 0;
                    while (clientNum<clientes.size()){
                        clientes.get(clientNum).mensajeCliente(String.valueOf("La resta de " + num1 + " y " + num2 + " = " + (num1 - num2)));
                        clientNum++;
                    }
                    System.out.println(String.valueOf(num1 + " - " + num2 + " = " + (num1 - num2)));

                    break;
                case "3":
                    clientNum = 0;
                    while (clientNum<clientes.size()){
                        clientes.get(clientNum).mensajeCliente(String.valueOf("La multiplicación de " + num1 + " y " + num2 + " = " + (num1 * num2)));
                        clientNum++;
                    }
                    System.out.println(String.valueOf(num1 + " * " + num2 + " = " + (num1 * num2)));                    
                    break;
                case "4":
                    clientNum = 0;
                    while (clientNum<clientes.size()){
                        clientes.get(clientNum).mensajeCliente(String.valueOf("La division de " + num1 + " y " + num2 + " = " + (num1 / num2)));
                        clientNum++;
                    }
                    System.out.println(String.valueOf(num1 + " / " + num2 + " = " +  (num1 / num2)));                    
                    break;
                case "5":
                    clientNum = 0;
                    while (clientNum<clientes.size()){
                        clientes.get(clientNum).mensajeCliente(String.valueOf("La potencia de " + num1 + " a la " + num2 + " = " + (Math.pow(num1,num2))));
                        clientNum++;
                    }
                    System.out.println(String.valueOf(num1 + " ^ " + num2 + " = " + (Math.pow(num1, num2))));
                    
                    break;
                case "6":
                    clientNum = 0;
                    while (clientNum<clientes.size()){
                        clientes.get(clientNum).mensajeCliente(String.valueOf("El modulo de " + num1 + " y " + num2 + " = " + (num1 % num2)));
                        clientNum++;
                    }
                    System.out.println(String.valueOf(num1 + " % " + num2 + " = " + + (num1 % num2)));
                    break;
            }//switch
            cont = 0;
        }//else


    }//mensaje
    public void registro(chatCliente cliente) throws RemoteException{
        this.clientes.add(cliente);
    }//registro
}//class
