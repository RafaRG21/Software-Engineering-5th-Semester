/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cliente;

import Interfaces.chatCliente;
import Interfaces.chatServidor;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;
/**
 *
 * @author Rafael Ruiz
 */
public class implementacionClienteChat extends UnicastRemoteObject implements chatCliente,Runnable{
    chatServidor servidor;
    public String nombre = null;
    implementacionClienteChat(String nombre, chatServidor servidor) throws RemoteException {
        this.nombre = nombre;
        this.servidor = servidor;
        servidor.registro(this);
    }//constructor

    @Override
    public void run() {
        Scanner scan = new Scanner(System.in);
        String mensaje,operacion;
        while (true) {
            System.out.print("Escribe un numero:");
            mensaje = scan.nextLine();
            try{
                System.out.println(nombre+" escribio: "+mensaje);
                System.out.println("Elige la operacion: \n1.-Suma \n2.-Resta \n3.-Multiplicacion \n4.-Division \n5-Potencia \n6.-Modulo" );
                operacion = scan.nextLine();
                servidor.mensaje(mensaje,nombre,operacion);

            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }

    @Override
    public void mensajeCliente(String mensaje) throws RemoteException {
        System.out.println("Resultado: "+mensaje);
    }
}//class
